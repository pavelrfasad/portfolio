#nullable disable
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using Autodesk.AutoCAD.EditorInput;
using Autodesk.AutoCAD.Geometry;
using Autodesk.AutoCAD.Runtime;
using Autodesk.AutoCAD.Windows;
using AcApp = Autodesk.AutoCAD.ApplicationServices.Application;

[assembly: CommandClass(typeof(DynamicBlockBatchAdjuster.Commands))]

namespace DynamicBlockBatchAdjuster
{
    public enum AxisMode
    {
        Length,
        Height
    }

    public enum AdjustMode
    {
        Trim,
        Extend
    }

    public enum SideMode
    {
        Start,
        End
    }

    internal sealed class AxisChoice
    {
        public AxisMode Axis;
        public SideMode Side;
        public double LengthValue;
        public double HeightValue;
        public Point3d SidePoint;
    }

    internal sealed class GroupReferenceChoice
    {
        public AxisMode Axis;
        public SideMode Side;
    }

    internal sealed class TargetResult
    {
        public Point3d NewPosition;
        public double NewValue;
        public bool HasResult;
    }

    public class Commands : IExtensionApplication
    {
        private static readonly string[] LengthAliases = { "l", "len", "length", "dl", "width", "w" };
        private static readonly string[] HeightAliases = { "h", "height", "dh", "v" };

        public void Initialize()
        {
            PaletteHost.EnsureVisible();
            Write("DynamicBlockBatchAdjuster загружен. Команды: DBSMARTTRIM, DBSMARTEXTEND, БЛОКОБРЕЗАТЬ, БЛОКУДЛИНИТЬ, DBPANEL.");
        }

        public void Terminate()
        {
        }

        [CommandMethod("DBPANEL")]
        public void ShowPanel()
        {
            PaletteHost.EnsureVisible();
        }

        [CommandMethod("DBSMARTTRIM")]
        [CommandMethod("БЛОКОБРЕЗАТЬ")]
        public void SmartTrim()
        {
            RunSmartBatch(AdjustMode.Trim);
        }

        [CommandMethod("DBSMARTEXTEND")]
        [CommandMethod("БЛОКУДЛИНИТЬ")]
        public void SmartExtend()
        {
            RunSmartBatch(AdjustMode.Extend);
        }

        private void RunSmartBatch(AdjustMode adjustMode)
        {
            Document doc = AcApp.DocumentManager.MdiActiveDocument;
            if (doc == null) return;

            Editor ed = doc.Editor;
            List<ObjectId> blockIds = PromptBlockSelection(ed);
            if (blockIds.Count == 0)
            {
                Write("Блоки не выбраны.");
                return;
            }

            PromptPointOptions ppo = new PromptPointOptions("\nУкажи сторону блока кликом: ");
            PromptPointResult ppr = ed.GetPoint(ppo);
            if (ppr.Status != PromptStatus.OK)
                return;

            Point3d cuePoint = ppr.Value;
            GroupReferenceChoice groupDirection = ResolveReferenceChoiceForSelection(doc, blockIds, cuePoint);

            List<ObjectId> boundaryIds = CollectAllBoundaryEntities(doc);
            if (boundaryIds.Count == 0)
            {
                Write("Границы не найдены.");
                return;
            }

            using (Transaction tr = doc.TransactionManager.StartTransaction())
            {
                int changed = 0;
                int skipped = 0;

                foreach (ObjectId id in blockIds)
                {
                    try
                    {
                        BlockReference br = tr.GetObject(id, OpenMode.ForWrite, false) as BlockReference;
                        if (br == null || !br.IsDynamicBlock)
                        {
                            skipped++;
                            continue;
                        }

                        DynamicBlockReferenceProperty propL = FindTargetProperty(br, AxisMode.Length);
                        DynamicBlockReferenceProperty propH = FindTargetProperty(br, AxisMode.Height);

                        double lengthValue = propL != null ? ToDouble(propL.Value) : 0.0;
                        double heightValue = propH != null ? ToDouble(propH.Value) : 0.0;

                        AxisChoice choice = ResolveAxisAndSideFromReferenceChoice(br, groupDirection, lengthValue, heightValue);
                        DynamicBlockReferenceProperty activeProp = choice.Axis == AxisMode.Length ? propL : propH;
                        if (activeProp == null)
                        {
                            Write(string.Format(CultureInfo.InvariantCulture,
                                "[{0}] skipped: no suitable parameter.", br.ObjectId.Handle));
                            skipped++;
                            continue;
                        }

                        if (activeProp.ReadOnly)
                        {
                            Write(string.Format(CultureInfo.InvariantCulture,
                                "[{0}] skipped: parameter '{1}' is read-only.",
                                br.ObjectId.Handle, activeProp.PropertyName));
                            skipped++;
                            continue;
                        }

                        TargetResult result = TryComputeSmartTarget(
                            br, choice.Axis, choice.Side, adjustMode, boundaryIds, id,
                            choice.Axis == AxisMode.Length ? lengthValue : heightValue);

                        if (!result.HasResult)
                        {
                            Write(string.Format(CultureInfo.InvariantCulture,
                                "[{0}] skipped: no boundary found for {1}/{2}.",
                                br.ObjectId.Handle, choice.Axis, choice.Side));
                            skipped++;
                            continue;
                        }

                        double currentValue = ToDouble(activeProp.Value);
                        if (Math.Abs(result.NewValue - currentValue) < 1e-9 &&
                            br.Position.DistanceTo(result.NewPosition) < 1e-9)
                        {
                            continue;
                        }

                        Vector3d blockShift = result.NewPosition - br.Position;
                        br.Position = result.NewPosition;
                        activeProp.Value = result.NewValue;

                        if (blockShift.Length > 1e-9)
                        {
                            PreserveAttributeLocalOffsets(br, tr, blockShift);
                        }

                        br.RecordGraphicsModified(true);

                        Write(string.Format(CultureInfo.InvariantCulture,
                            "[{0}] {1}/{2}: {3} -> {4}",
                            br.ObjectId.Handle,
                            choice.Axis,
                            choice.Side,
                            FormatNumber(currentValue),
                            FormatNumber(result.NewValue)));

                        changed++;
                    }
                    catch (System.Exception ex)
                    {
                        Write(string.Format(CultureInfo.InvariantCulture,
                            "[{0}] error: {1}", id.Handle, ex.Message));
                        skipped++;
                    }
                }

                tr.Commit();
                ed.Regen();
                Write(string.Format(CultureInfo.InvariantCulture,
                    "{0} done. Changed={1}, Skipped={2}",
                    adjustMode.ToString().ToUpperInvariant(), changed, skipped));
            }
        }

        private static List<ObjectId> PromptBlockSelection(Editor ed)
        {
            PromptSelectionOptions pso = new PromptSelectionOptions();
            pso.MessageForAdding = "\nВыбери динамические блоки: ";
            pso.MessageForRemoval = "\nУбери блоки: ";

            SelectionFilter filter = new SelectionFilter(new[]
            {
                new TypedValue((int)DxfCode.Start, "INSERT")
            });

            PromptSelectionResult psr = ed.GetSelection(pso, filter);
            if (psr.Status != PromptStatus.OK) return new List<ObjectId>();
            return psr.Value.GetObjectIds().ToList();
        }

        private static List<ObjectId> CollectAllBoundaryEntities(Document doc)
        {
            List<ObjectId> ids = new List<ObjectId>();

            using (Transaction tr = doc.TransactionManager.StartTransaction())
            {
                BlockTableRecord space = tr.GetObject(doc.Database.CurrentSpaceId, OpenMode.ForRead) as BlockTableRecord;
                if (space != null)
                {
                    foreach (ObjectId id in space)
                    {
                        Entity ent = tr.GetObject(id, OpenMode.ForRead, false) as Entity;
                        if (ent != null)
                            ids.Add(id);
                    }
                }

                tr.Commit();
            }

            return ids;
        }

        private static DynamicBlockReferenceProperty FindTargetProperty(BlockReference br, AxisMode mode)
        {
            string[] aliases = mode == AxisMode.Length ? LengthAliases : HeightAliases;
            List<DynamicBlockReferenceProperty> props = br.DynamicBlockReferencePropertyCollection
                .Cast<DynamicBlockReferenceProperty>()
                .ToList();

            Func<string, string> normalize = s =>
            {
                char[] chars = s.ToLowerInvariant().Where(char.IsLetterOrDigit).ToArray();
                return new string(chars);
            };

            foreach (DynamicBlockReferenceProperty prop in props)
            {
                string normalizedProp = normalize(prop.PropertyName);
                foreach (string alias in aliases)
                {
                    if (normalizedProp == normalize(alias))
                        return prop;
                }
            }

            foreach (DynamicBlockReferenceProperty prop in props)
            {
                string normalizedProp = normalize(prop.PropertyName);
                foreach (string alias in aliases)
                {
                    if (normalizedProp.Contains(normalize(alias)))
                        return prop;
                }
            }

            List<DynamicBlockReferenceProperty> distanceProps = props
                .Where(p => p.UnitsType == DynamicBlockReferencePropertyUnitsType.Distance && !p.ReadOnly)
                .ToList();

            if (distanceProps.Count == 1)
                return distanceProps[0];

            return mode == AxisMode.Length
                ? distanceProps.FirstOrDefault()
                : distanceProps.Skip(1).FirstOrDefault() ?? distanceProps.FirstOrDefault();
        }

        private static GroupReferenceChoice ResolveReferenceChoiceForSelection(Document doc, List<ObjectId> blockIds, Point3d cuePoint)
        {
            ObjectId nearestId = ObjectId.Null;
            double bestDistance = double.MaxValue;

            using (Transaction tr = doc.TransactionManager.StartOpenCloseTransaction())
            {
                foreach (ObjectId id in blockIds)
                {
                    BlockReference br = tr.GetObject(id, OpenMode.ForRead, false) as BlockReference;
                    if (br == null)
                        continue;

                    double d = br.Position.DistanceTo(cuePoint);
                    if (d < bestDistance)
                    {
                        bestDistance = d;
                        nearestId = id;
                    }
                }

                if (nearestId != ObjectId.Null)
                {
                    BlockReference nearest = tr.GetObject(nearestId, OpenMode.ForRead, false) as BlockReference;
                    if (nearest != null)
                    {
                        DynamicBlockReferenceProperty propL = FindTargetProperty(nearest, AxisMode.Length);
                        DynamicBlockReferenceProperty propH = FindTargetProperty(nearest, AxisMode.Height);
                        double lengthValue = propL != null ? ToDouble(propL.Value) : 0.0;
                        double heightValue = propH != null ? ToDouble(propH.Value) : 0.0;

                        AxisChoice localChoice = ResolveAxisAndSide(nearest, cuePoint, lengthValue, heightValue);
                        tr.Commit();

                        return new GroupReferenceChoice
                        {
                            Axis = localChoice.Axis,
                            Side = localChoice.Side
                        };
                    }
                }

                tr.Commit();
            }

            return new GroupReferenceChoice
            {
                Axis = AxisMode.Length,
                Side = SideMode.End
            };
        }

        private static AxisChoice ResolveAxisAndSide(BlockReference br, Point3d cuePoint, double lengthValue, double heightValue)
        {
            Point3d origin = br.Position;
            Vector3d dirL = Vector3d.XAxis.TransformBy(br.BlockTransform);
            Vector3d dirH = Vector3d.YAxis.TransformBy(br.BlockTransform);

            if (dirL.Length < 1e-9) dirL = Vector3d.XAxis;
            if (dirH.Length < 1e-9) dirH = Vector3d.YAxis;

            dirL = dirL.GetNormal();
            dirH = dirH.GetNormal();

            double len = Math.Max(lengthValue, 0.0);
            double h = Math.Max(heightValue, 0.0);

            Point3d lengthStart = origin + dirH * (h * 0.5);
            Point3d lengthEnd = origin + dirL * len + dirH * (h * 0.5);
            Point3d heightStart = origin + dirL * (len * 0.5);
            Point3d heightEnd = origin + dirH * h + dirL * (len * 0.5);

            var candidates = new List<AxisChoice>
            {
                new AxisChoice { Axis = AxisMode.Length, Side = SideMode.Start, LengthValue = lengthValue, HeightValue = heightValue, SidePoint = lengthStart },
                new AxisChoice { Axis = AxisMode.Length, Side = SideMode.End, LengthValue = lengthValue, HeightValue = heightValue, SidePoint = lengthEnd },
                new AxisChoice { Axis = AxisMode.Height, Side = SideMode.Start, LengthValue = lengthValue, HeightValue = heightValue, SidePoint = heightStart },
                new AxisChoice { Axis = AxisMode.Height, Side = SideMode.End, LengthValue = lengthValue, HeightValue = heightValue, SidePoint = heightEnd }
            };

            return candidates.OrderBy(c => c.SidePoint.DistanceTo(cuePoint)).First();
        }

        private static AxisChoice ResolveAxisAndSideFromReferenceChoice(
            BlockReference br,
            GroupReferenceChoice referenceChoice,
            double lengthValue,
            double heightValue)
        {
            Point3d origin = br.Position;
            Vector3d dirL = Vector3d.XAxis.TransformBy(br.BlockTransform);
            Vector3d dirH = Vector3d.YAxis.TransformBy(br.BlockTransform);

            if (dirL.Length < 1e-9) dirL = Vector3d.XAxis;
            if (dirH.Length < 1e-9) dirH = Vector3d.YAxis;

            dirL = dirL.GetNormal();
            dirH = dirH.GetNormal();

            Point3d sidePoint;
            if (referenceChoice.Axis == AxisMode.Length)
                sidePoint = referenceChoice.Side == SideMode.End ? origin + dirL * Math.Max(lengthValue, 0.0) : origin;
            else
                sidePoint = referenceChoice.Side == SideMode.End ? origin + dirH * Math.Max(heightValue, 0.0) : origin;

            return new AxisChoice
            {
                Axis = referenceChoice.Axis,
                Side = referenceChoice.Side,
                LengthValue = lengthValue,
                HeightValue = heightValue,
                SidePoint = sidePoint
            };
        }

        private static TargetResult TryComputeSmartTarget(
            BlockReference br,
            AxisMode axisMode,
            SideMode sideMode,
            AdjustMode adjustMode,
            IEnumerable<ObjectId> boundaryIds,
            ObjectId selfId,
            double currentValue)
        {
            TargetResult result = new TargetResult
            {
                NewPosition = br.Position,
                NewValue = currentValue,
                HasResult = false
            };

            Vector3d dir = (axisMode == AxisMode.Length ? Vector3d.XAxis : Vector3d.YAxis).TransformBy(br.BlockTransform);
            if (dir.Length < 1e-9) return result;
            dir = dir.GetNormal();

            Point3d origin = br.Position;
            Line axisLine = new Line(origin - dir * 1000000.0, origin + dir * 1000000.0);
            List<double> candidates = new List<double>();

            Document doc = AcApp.DocumentManager.MdiActiveDocument;
            if (doc == null) return result;

            using (Transaction tr = doc.TransactionManager.StartTransaction())
            {
                foreach (ObjectId boundaryId in boundaryIds)
                {
                    if (boundaryId == selfId)
                        continue;

                    Entity ent = tr.GetObject(boundaryId, OpenMode.ForRead, false) as Entity;
                    if (ent == null)
                        continue;

                    CollectEntityIntersections(ent, axisLine, origin, dir, candidates);
                }

                tr.Commit();
            }

            if (candidates.Count == 0)
                return result;

            double tol = 1e-9;
            if (sideMode == SideMode.End)
            {
                if (adjustMode == AdjustMode.Trim)
                {
                    var filtered = candidates.Where(d => d > tol && d < currentValue - tol).ToList();
                    if (filtered.Count == 0) return result;

                    result.NewValue = filtered.Max();
                    result.NewPosition = origin;
                    result.HasResult = true;
                    return result;
                }
                else
                {
                    var filtered = candidates.Where(d => d > currentValue + tol).ToList();
                    if (filtered.Count == 0) return result;

                    result.NewValue = filtered.Min();
                    result.NewPosition = origin;
                    result.HasResult = true;
                    return result;
                }
            }
            else
            {
                if (adjustMode == AdjustMode.Trim)
                {
                    var filtered = candidates.Where(d => d > tol && d < currentValue - tol).ToList();
                    if (filtered.Count == 0) return result;

                    double shift = filtered.Min();
                    result.NewPosition = origin + dir * shift;
                    result.NewValue = currentValue - shift;
                    result.HasResult = true;
                    return result;
                }
                else
                {
                    var filtered = candidates.Where(d => d < -tol).ToList();
                    if (filtered.Count == 0) return result;

                    double signed = filtered.Max();
                    result.NewPosition = origin + dir * signed;
                    result.NewValue = currentValue - signed;
                    result.HasResult = true;
                    return result;
                }
            }
        }

        private static void CollectEntityIntersections(Entity ent, Line axisLine, Point3d origin, Vector3d dir, List<double> candidates)
        {
            Point3dCollection pts = new Point3dCollection();

            try
            {
                ent.IntersectWith(axisLine, Intersect.OnBothOperands, pts, IntPtr.Zero, IntPtr.Zero);
            }
            catch
            {
            }

            foreach (Point3d pt in pts)
            {
                AddCandidateDistance(origin, dir, pt, candidates);
            }

            if (pts.Count > 0)
                return;

            try
            {
                Extents3d ex = ent.GeometricExtents;
                AddExtentsIntersections(ex, axisLine, origin, dir, candidates);
            }
            catch
            {
            }
        }

        private static void AddCandidateDistance(Point3d origin, Vector3d dir, Point3d pt, List<double> candidates)
        {
            double distance = (pt - origin).DotProduct(dir);
            candidates.Add(distance);
        }

        private static void AddExtentsIntersections(Extents3d ex, Line axisLine, Point3d origin, Vector3d dir, List<double> candidates)
        {
            Point3d a = new Point3d(ex.MinPoint.X, ex.MinPoint.Y, 0);
            Point3d b = new Point3d(ex.MaxPoint.X, ex.MinPoint.Y, 0);
            Point3d c = new Point3d(ex.MaxPoint.X, ex.MaxPoint.Y, 0);
            Point3d d = new Point3d(ex.MinPoint.X, ex.MaxPoint.Y, 0);

            TryAddLineIntersection(a, b, axisLine.StartPoint, axisLine.EndPoint, origin, dir, candidates);
            TryAddLineIntersection(b, c, axisLine.StartPoint, axisLine.EndPoint, origin, dir, candidates);
            TryAddLineIntersection(c, d, axisLine.StartPoint, axisLine.EndPoint, origin, dir, candidates);
            TryAddLineIntersection(d, a, axisLine.StartPoint, axisLine.EndPoint, origin, dir, candidates);
        }

        private static void TryAddLineIntersection(Point3d p1, Point3d p2, Point3d p3, Point3d p4, Point3d origin, Vector3d dir, List<double> candidates)
        {
            double x1 = p1.X, y1 = p1.Y;
            double x2 = p2.X, y2 = p2.Y;
            double x3 = p3.X, y3 = p3.Y;
            double x4 = p4.X, y4 = p4.Y;

            double den = (x1 - x2) * (y3 - y4) - (y1 - y2) * (x3 - x4);
            if (Math.Abs(den) < 1e-9)
                return;

            double t = ((x1 - x3) * (y3 - y4) - (y1 - y3) * (x3 - x4)) / den;
            double u = ((x1 - x3) * (y1 - y2) - (y1 - y3) * (x1 - x2)) / den;

            if (t < -1e-9 || t > 1.0 + 1e-9)
                return;

            if (u < -1e-9 || u > 1.0 + 1e-9)
                return;

            double x = x1 + t * (x2 - x1);
            double y = y1 + t * (y2 - y1);
            AddCandidateDistance(origin, dir, new Point3d(x, y, 0), candidates);
        }

        private static void PreserveAttributeLocalOffsets(BlockReference br, Transaction tr, Vector3d blockShift)
        {
            foreach (ObjectId attId in br.AttributeCollection)
            {
                AttributeReference ar = tr.GetObject(attId, OpenMode.ForWrite, false) as AttributeReference;
                if (ar == null)
                    continue;

                ar.Position = ar.Position + blockShift;

                try
                {
                    if (ar.IsMTextAttribute)
                    {
                        ar.AlignmentPoint = ar.AlignmentPoint + blockShift;
                    }
                    else if (ar.Justify != AttachmentPoint.BaseLeft)
                    {
                        ar.AlignmentPoint = ar.AlignmentPoint + blockShift;
                    }
                }
                catch
                {
                }

                try
                {
                    ar.AdjustAlignment(br.Database);
                }
                catch
                {
                }
            }
        }

        private static double ToDouble(object value)
        {
            if (value is double) return (double)value;
            if (value is int) return (int)value;
            if (value is short) return (short)value;
            if (value is float) return (float)value;
            if (value is decimal) return (double)(decimal)value;
            return Convert.ToDouble(value, CultureInfo.InvariantCulture);
        }

        private static string FormatNumber(double value)
        {
            return value.ToString("0.###", CultureInfo.InvariantCulture);
        }

        private static void Write(string message)
        {
            Document doc = AcApp.DocumentManager.MdiActiveDocument;
            if (doc != null)
                doc.Editor.WriteMessage("\n" + message);
        }
    }

    internal static class PaletteHost
    {
        private static readonly Guid ToolId = new Guid("B42A69A2-34B9-4B2A-9D8E-5B27F3F1D9A4");
        private static PaletteSet palette;
        private static BlockBatchPalette content;

        public static void EnsureVisible()
        {
            if (palette == null)
            {
                content = new BlockBatchPalette();
                palette = new PaletteSet("DB Blocks", ToolId);
                palette.Size = new Size(260, 120);
                palette.Add("Блоки", content);
            }

            palette.Visible = true;
        }
    }

    internal sealed class BlockBatchPalette : UserControl
    {
        private readonly Button trimButton;
        private readonly Button extendButton;

        public BlockBatchPalette()
        {
            Dock = DockStyle.Fill;
            BackColor = Color.WhiteSmoke;
            Padding = new Padding(10);

            TableLayoutPanel root = new TableLayoutPanel();
            root.Dock = DockStyle.Top;
            root.AutoSize = true;
            root.ColumnCount = 2;
            root.RowCount = 1;
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            root.RowStyles.Add(new RowStyle(SizeType.Absolute, 34F));

            trimButton = MakeButton("Обрезать", OnTrim);
            extendButton = MakeButton("Удлинить", OnExtend);

            root.Controls.Add(trimButton, 0, 0);
            root.Controls.Add(extendButton, 1, 0);

            Controls.Add(root);
        }

        private static Button MakeButton(string text, EventHandler handler)
        {
            Button button = new Button();
            button.Text = text;
            button.Dock = DockStyle.Fill;
            button.Height = 30;
            button.Click += handler;
            return button;
        }

        private static void SendCommand(string command)
        {
            Document doc = AcApp.DocumentManager.MdiActiveDocument;
            if (doc == null) return;

            doc.SendStringToExecute("._" + command + " ", true, false, false);
        }

        private void OnTrim(object sender, EventArgs e) => SendCommand("DBSMARTTRIM");
        private void OnExtend(object sender, EventArgs e) => SendCommand("DBSMARTEXTEND");
    }
}
