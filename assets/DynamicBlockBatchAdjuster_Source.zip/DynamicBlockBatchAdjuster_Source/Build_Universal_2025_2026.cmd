@echo off
setlocal
echo Building DynamicBlockBatchAdjuster universal DLL for AutoCAD 2025 + 2026...
dotnet build
echo.
pause
