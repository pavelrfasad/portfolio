# DynamicBlockBatchAdjuster — универсальная сборка для AutoCAD 2025 + 2026

Эта структура настроена на **одну DLL** для AutoCAD 2025 и 2026.

## Принцип
Проект собирается **против библиотек AutoCAD 2026**:
`C:\Program Files\Autodesk\AutoCAD 2026\`

Это сделано потому, что по таблице совместимости Autodesk:
- AutoCAD 2025 работает на .NET 8.0
- AutoCAD 2026 тоже работает на .NET 8.0
- SDK AutoCAD 2026 поддерживает AutoCAD 2026 и AutoCAD 2025

## Что делать
1. Открой `DynamicBlockBatchAdjuster.sln`
2. Выполни `dotnet build`
3. Получишь:
   `bin\Debug\net8.0-windows\DynamicBlockBatchAdjuster.dll`
4. Протестируй эту DLL через `NETLOAD`:
   - в AutoCAD 2026
   - в AutoCAD 2025

## Важно
Это **универсальная сборка 2025+2026**, но не 2024 и ниже.
Для AutoCAD 2024 и ниже нужна отдельная ветка на .NET Framework 4.8.

## Если на сборочной машине нет AutoCAD 2026
Тогда этот универсальный вариант не собрать как есть.
В таком случае:
- либо временно ставишь AutoCAD 2026 SDK/сам AutoCAD 2026
- либо собираешь отдельную DLL под AutoCAD 2025 из другой структуры

## Команды в плагине
- `DBSMARTTRIM`
- `DBSMARTEXTEND`
- `БЛОКОБРЕЗАТЬ`
- `БЛОКУДЛИНИТЬ`
- `DBPANEL`
