@echo off
setlocal
dotnet build
pause
